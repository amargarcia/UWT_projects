/**
 * @author AJ Garcia
 */
import java.util.Scanner;

public class Minesweeper {
    public static void main(String[] args) {
        Scanner input  = new Scanner(System.in);
        int column = 0;
        int row = 0;
        int rCount = 1;
        char[][] matrix = new char[column][row];
        String line;
        int fieldNum = 1;

        while (input.hasNextLine()) {

            if (input.hasNextInt()) {
                row = input.nextInt();
                if (row == 0) {
                    System.exit(0);
                }
                column = input.nextInt();
                input.nextLine();
                matrix = new char[row + 2][column + 2];
                rCount = 1;
                System.out.println("Field #" + fieldNum + ":");
                fieldNum++;
            } else {
                check_range(row, column);
                line = input.nextLine();

                for (int i = 1; i < column + 1; i++) {
                    matrix[rCount][i] = line.charAt(i-1);
                }
                rCount++;
            }
            if (rCount == row +1) {
                print_matrix(matrix);
            }

        }
    }
    public static void check_range(int c, int r) {
        if (c > 100 || c < 0 || r > 100 || r < 0) {
            System.exit(-1);
        }
    }

    public static void print_matrix(char[][] m){
        int mines = 0;
        for (int r = 1; r < m.length - 1; r++){
            for (int c = 1; c < m[r].length - 1; c++) {
                if (m[r][c] != '*') {
                    if (m[r-1][c-1] == '*') {
                        mines++;
                    }
                    if (m[r-1][c] == '*') {
                        mines++;
                    }
                    if (m[r-1][c+1] == '*') {
                        mines++;
                    }
                    if (m[r][c-1] == '*') {
                        mines++;
                    }
                    if (m[r][c+1] == '*') {
                        mines++;
                    }
                    if (m[r+1][c-1] == '*') {
                        mines++;
                    }
                    if (m[r+1][c] == '*') {
                        mines++;
                    }
                    if (m[r+1][c+1] == '*') {
                        mines++;
                    }
                    System.out.print(mines);
                    mines = 0;
                } else {
                    System.out.print(m[r][c]);
                }
            }
            System.out.println();
        }
        System.out.println();
    }
}